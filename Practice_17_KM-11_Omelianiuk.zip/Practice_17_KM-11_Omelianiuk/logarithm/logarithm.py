import math
from math import e
def log(x, a):
    return math.log(x, a)
def lg(x):
    return math.log(x, 10)
def ln(x):
    return math.log(x, e)