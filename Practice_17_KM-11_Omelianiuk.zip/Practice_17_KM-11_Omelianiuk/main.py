import math
from factorial import factorial
from exp_root import exponentiation, root
from logarithm import logarithm
def iswrong(func, *args):
    try:
        func(*args)
        return True
    except (ValueError, TypeError) as e:
        print(f"Error occurred: {e}")
        return False
def choose_program():
    print("\nВиберіть опцію:")
    print("1. Факторіал")
    print("2. Піднесення до степеня (2 або 3)")
    print("3. Корінь (2 або 3)")
    print("4. Логарифм (ln, lg або log)")
    print("5. Вихід")
    p = input("Ваш вибір: ")

    if p == '1':
        try:
            x = int(input("Число для факторіалу: "))
            if iswrong(factorial.fact, x):
                print(f"Факторіал {x} = {factorial.fact(x)}")
        except ValueError:
            print("Помилка! Введіть число.")
            
    elif p == '2':
        try:
            x = float(input("Число для степеня: "))
            s = input("2 або 3: ")
            if s == '2':
                if iswrong(exponentiation.exp2, x):
                    print(f"{x} у квадраті = {exponentiation.exp2(x)}")
            elif s == '3':
                if iswrong(exponentiation.exp3, x):
                    print(f"{x} у кубі = {exponentiation.exp3(x)}")
            else:
                print("Невірний вибір.")
        except ValueError:
            print("Помилка! Введіть число.")

    elif p == '3':
        try:
            x = float(input("Число для кореня: "))
            s = input("2 або 3: ")
            if s == '2':
                if iswrong(root.root2, x):
                    print(f"Квадратний корінь {x} = {root.root2(x)}")
            elif s == '3':
                if iswrong(root.root3, x):
                    print(f"Кубічний корінь {x} = {root.root3(x)}")
            else:
                print("Невірний вибір.")
        except ValueError:
            print("Помилка! Введіть число.")

    elif p == '4':
        try:
            x = float(input("Число для логарифма: "))
            s = input("1 (ln), 2 (lg), 3 (log): ")
            if s == '1':
                if iswrong(logarithm.ln, x):
                    print(f"ln({x}) = {logarithm.ln(x)}")
            elif s == '2':
                if iswrong(logarithm.lg, x):
                    print(f"lg({x}) = {logarithm.lg(x)}")
            elif s == '3':
                a = float(input("Основа: "))
                if iswrong(logarithm.log, a, x):
                    print(f"log({x}) з основою {a} = {logarithm.log(x, a)}")
            else:
                print("Невірний вибір.")
        except ValueError:
            print("Помилка! Введіть число.")
            
    elif p == '5':
        exit(0)
    else:
        print("Невірний вибір.")

q = 0
if __name__=="__main__":
    while q == 0:
        choose_program() 