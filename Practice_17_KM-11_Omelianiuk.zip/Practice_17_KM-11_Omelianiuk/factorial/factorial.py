from math import factorial
def fact(x):
    return factorial(x)