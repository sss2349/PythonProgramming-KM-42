from math import sqrt
def root(x):
    return sqrt(x)
def root2(x):
    return x**(1/3)